/* ══════════════════════════════════════
   IndoGulf Wellness — script.js
   ══════════════════════════════════════ */

(function () {
  const style = document.createElement('style');
  style.textContent = `@keyframes stepIn{0%{opacity:0;transform:scale(0.4)}60%{opacity:0.7}100%{opacity:0.55;transform:scale(1)}}`;
  document.head.appendChild(style);

  const footsteps = [
    {x:263,y:112,flip:0,d:2.0},{x:272,y:104,flip:1,d:2.2},{x:283,y:110,flip:0,d:2.4},
    {x:292,y:103,flip:1,d:2.6},{x:304,y:108,flip:0,d:2.8},{x:315,y:103,flip:1,d:3.0},
    {x:370,y:105,flip:0,d:3.2},{x:382,y:100,flip:1,d:3.4},{x:394,y:105,flip:0,d:3.6},
    {x:406,y:100,flip:1,d:3.8},{x:428,y:168,flip:0,d:4.0},{x:434,y:180,flip:1,d:4.2},
    {x:428,y:194,flip:0,d:4.4},{x:434,y:208,flip:1,d:4.6},{x:428,y:222,flip:0,d:4.8},
    {x:480,y:468,flip:0,d:5.0},{x:494,y:473,flip:1,d:5.2},{x:508,y:468,flip:0,d:5.4},
    {x:522,y:473,flip:1,d:5.6},{x:538,y:468,flip:0,d:5.8},
  ];

  function makeFoot(x,y,flip,delay){
    const ns='http://www.w3.org/2000/svg';
    const g=document.createElementNS(ns,'g');
    g.setAttribute('transform',`translate(${x},${y}) scale(${flip?-1:1},1)`);
    g.style.cssText=`opacity:0;animation:stepIn 0.35s ease ${delay}s forwards`;
    const foot=document.createElementNS(ns,'ellipse');
    foot.setAttribute('cx','0');foot.setAttribute('cy','0');
    foot.setAttribute('rx','3.5');foot.setAttribute('ry','6');
    foot.setAttribute('fill','#1a3a2e');g.appendChild(foot);
    for(let i=0;i<4;i++){
      const t=document.createElementNS(ns,'ellipse');
      t.setAttribute('cx',String(-3+i*2.2));t.setAttribute('cy','-7');
      t.setAttribute('rx','1.5');t.setAttribute('ry','2');
      t.setAttribute('fill','#1a3a2e');g.appendChild(t);
    }
    return g;
  }

  const layer=document.getElementById('steps-layer');
  if(layer) footsteps.forEach(f=>layer.appendChild(makeFoot(f.x,f.y,f.flip,f.d)));

  const pre=document.getElementById('preloader');
  function dismiss(e){
    if(e&&e.cancelable)e.preventDefault();
    if(pre) pre.classList.add('dismissed');
    document.body.style.overflow='';
    setTimeout(initHeroAnimations,800);
  }
  if(pre){
    pre.addEventListener('click',dismiss);
    pre.addEventListener('touchend',dismiss,{passive:false});
  }
})();

// ══ CUSTOM CURSOR ══
const cursor=document.getElementById('cursor');
const cursorRing=document.getElementById('cursorRing');
let mouseX=0,mouseY=0,ringX=0,ringY=0;
document.addEventListener('mousemove',e=>{mouseX=e.clientX;mouseY=e.clientY;});
(function animCursor(){
  if(cursor){cursor.style.left=mouseX+'px';cursor.style.top=mouseY+'px';}
  ringX+=(mouseX-ringX)*0.12;ringY+=(mouseY-ringY)*0.12;
  if(cursorRing){cursorRing.style.left=ringX+'px';cursorRing.style.top=ringY+'px';}
  requestAnimationFrame(animCursor);
})();
document.querySelectorAll('a,button,.service-card,.program-item,.dosha-card').forEach(el=>{
  el.addEventListener('mouseenter',()=>{if(cursor){cursor.style.width='16px';cursor.style.height='16px';cursor.style.background='#fff';}});
  el.addEventListener('mouseleave',()=>{if(cursor){cursor.style.width='8px';cursor.style.height='8px';cursor.style.background='var(--gold-main)';}});
});

// ══ THREE.JS HERO ══
(function initHero(){
  const canvas=document.getElementById('three-canvas');
  if(!canvas||typeof THREE==='undefined')return;
  const renderer=new THREE.WebGLRenderer({canvas,alpha:true,antialias:true});
  renderer.setPixelRatio(Math.min(window.devicePixelRatio,2));
  const w=window.innerWidth,h=window.innerHeight;
  renderer.setSize(w,h);
  const scene=new THREE.Scene();
  const camera=new THREE.PerspectiveCamera(60,w/h,0.1,100);
  camera.position.set(0,0,5);
  const group=new THREE.Group(); scene.add(group);
  const mat1=new THREE.MeshBasicMaterial({color:0xd4a843,wireframe:true,transparent:true,opacity:0.15});
  const mat2=new THREE.MeshBasicMaterial({color:0x7a9e7e,wireframe:true,transparent:true,opacity:0.10});
  const mat3=new THREE.MeshBasicMaterial({color:0xc4956a,wireframe:true,transparent:true,opacity:0.08});
  const t1=new THREE.Mesh(new THREE.TorusKnotGeometry(1.6,0.3,180,20,3,5),mat1);
  const t2=new THREE.Mesh(new THREE.TorusKnotGeometry(2.2,0.15,160,16,5,3),mat2);
  const t3=new THREE.Mesh(new THREE.TorusGeometry(2.8,0.04,8,120),mat3);
  const t4=new THREE.Mesh(new THREE.TorusGeometry(3.4,0.02,8,120),mat3);
  const t5=new THREE.Mesh(new THREE.IcosahedronGeometry(1,2),new THREE.MeshBasicMaterial({color:0xd4a843,wireframe:true,transparent:true,opacity:0.06}));
  group.add(t1,t2,t3,t4,t5); group.position.set(3,0,-1);
  const pts=[];
  for(let i=0;i<300;i++)pts.push((Math.random()-.5)*14,(Math.random()-.5)*10,(Math.random()-.5)*8);
  const partGeo=new THREE.BufferGeometry();
  partGeo.setAttribute('position',new THREE.Float32BufferAttribute(pts,3));
  const partMesh=new THREE.Points(partGeo,new THREE.PointsMaterial({color:0xd4a843,size:0.025,transparent:true,opacity:0.5}));
  scene.add(partMesh);
  let mx=0,my=0;
  document.addEventListener('mousemove',e=>{mx=(e.clientX/window.innerWidth-.5)*2;my=-(e.clientY/window.innerHeight-.5)*2;});
  function render(t){
    requestAnimationFrame(render); t*=0.001;
    t1.rotation.x=t*0.3;t1.rotation.y=t*0.5;
    t2.rotation.x=-t*0.2;t2.rotation.z=t*0.4;
    t3.rotation.z=t*0.15;t4.rotation.z=-t*0.1;
    t5.rotation.x=t*0.4;t5.rotation.y=t*0.3;
    group.rotation.y+=(mx*0.3-group.rotation.y)*0.04;
    group.rotation.x+=(my*0.2-group.rotation.x)*0.04;
    partMesh.rotation.y=t*0.05;
    renderer.render(scene,camera);
  }
  render(0);
  window.addEventListener('resize',()=>{
    const w2=window.innerWidth,h2=window.innerHeight;
    camera.aspect=w2/h2;camera.updateProjectionMatrix();renderer.setSize(w2,h2);
  });
})();

// ══ THREE.JS MIND ══
(function initMind(){
  const canvas=document.getElementById('mind-canvas');
  if(!canvas||typeof THREE==='undefined')return;
  const renderer=new THREE.WebGLRenderer({canvas,alpha:true,antialias:true});
  renderer.setPixelRatio(Math.min(window.devicePixelRatio,2));
  const size=canvas.clientWidth||400; renderer.setSize(size,size);
  const scene=new THREE.Scene();
  const camera=new THREE.PerspectiveCamera(55,1,0.1,100); camera.position.z=3.5;
  const sphere=new THREE.Mesh(new THREE.SphereGeometry(1.2,64,64),new THREE.MeshBasicMaterial({color:0x7a9e7e,wireframe:true,transparent:true,opacity:0.25}));
  const inner=new THREE.Mesh(new THREE.SphereGeometry(0.85,32,32),new THREE.MeshBasicMaterial({color:0xd4a843,wireframe:true,transparent:true,opacity:0.15}));
  const ring1=new THREE.Mesh(new THREE.TorusGeometry(1.5,0.012,8,120),new THREE.MeshBasicMaterial({color:0xd4a843,transparent:true,opacity:0.3}));
  const ring2=new THREE.Mesh(new THREE.TorusGeometry(1.75,0.008,8,120),new THREE.MeshBasicMaterial({color:0xc4956a,transparent:true,opacity:0.2}));
  ring1.rotation.x=Math.PI/2.5; ring2.rotation.x=-Math.PI/3;
  scene.add(sphere,inner,ring1,ring2);
  function render(t){
    requestAnimationFrame(render); t*=0.001;
    sphere.rotation.y=t*0.2;sphere.rotation.x=t*0.1;
    inner.rotation.y=-t*0.3;inner.rotation.z=t*0.15;
    ring1.rotation.z=t*0.1;ring2.rotation.y=t*0.08;
    renderer.render(scene,camera);
  }
  render(0);
})();

// ══ NAV SCROLL ══
window.addEventListener('scroll',()=>{
  const nb=document.getElementById('navbar');
  if(nb)nb.classList.toggle('scrolled',window.scrollY>80);
});

// ══ GSAP ANIMATIONS ══
function initHeroAnimations(){
  if(typeof gsap==='undefined')return;
  gsap.registerPlugin(ScrollTrigger);
  gsap.timeline()
    .to('.hero-eyebrow',{opacity:1,y:0,duration:0.8,ease:'power3.out'})
    .to('.hero-title',{opacity:1,y:0,duration:1,ease:'power3.out'},'-=0.5')
    .to('.hero-sub',{opacity:1,y:0,duration:0.8,ease:'power3.out'},'-=0.6')
    .to('.hero-btns',{opacity:1,y:0,duration:0.7,ease:'power3.out'},'-=0.5')
    .to('.scroll-indicator',{opacity:1,duration:0.6},'-=0.2');
  gsap.utils.toArray('.reveal').forEach(el=>{
    gsap.fromTo(el,{opacity:0,y:50},{opacity:1,y:0,duration:1,ease:'power3.out',scrollTrigger:{trigger:el,start:'top 82%',toggleActions:'play none none none'}});
  });
  gsap.utils.toArray('.reveal-left').forEach(el=>{
    gsap.fromTo(el,{opacity:0,x:-50},{opacity:1,x:0,duration:1,ease:'power3.out',scrollTrigger:{trigger:el,start:'top 82%',toggleActions:'play none none none'}});
  });
  gsap.fromTo('.service-card',{opacity:0,scale:0.92},{opacity:1,scale:1,duration:0.7,stagger:0.1,ease:'power3.out',scrollTrigger:{trigger:'.services-grid',start:'top 75%'}});
  document.querySelectorAll('[data-target]').forEach(el=>{
    ScrollTrigger.create({trigger:el,start:'top 85%',once:true,onEnter:()=>{
      const target=+el.dataset.target;
      gsap.to({val:0},{val:target,duration:2,ease:'power2.out',onUpdate:function(){el.textContent=Math.round(this.targets()[0].val).toLocaleString();}});
    }});
  });
  gsap.fromTo('.program-item',{opacity:0,x:-30},{opacity:1,x:0,duration:0.6,stagger:0.12,ease:'power2.out',scrollTrigger:{trigger:'.programs-list',start:'top 78%'}});
  gsap.to('.hero-content',{y:-100,ease:'none',scrollTrigger:{trigger:'#hero',start:'top top',end:'bottom top',scrub:true}});
  document.querySelectorAll('.dosha-card').forEach(card=>{
    card.addEventListener('mouseenter',()=>gsap.to(card,{scale:1.02,duration:0.3}));
    card.addEventListener('mouseleave',()=>gsap.to(card,{scale:1,duration:0.3}));
  });
  const slider=document.getElementById('testiSlider');
  if(slider){
    let sliderPos=0;
    Array.from(slider.children).forEach(c=>slider.appendChild(c.cloneNode(true)));
    const totalW=slider.scrollWidth/2;
    function animSlider(){sliderPos+=0.5;if(sliderPos>=totalW)sliderPos=0;slider.scrollLeft=sliderPos;requestAnimationFrame(animSlider);}
    requestAnimationFrame(animSlider);
  }
}
