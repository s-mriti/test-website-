<?php
/**
 * IndoGulf Wellness — index.php
 * The main template file.
 */
get_header();
?>

<!-- ════ PRELOADER ════ -->
<div id="preloader">
  <div id="map-wrap">
    <div id="parchment">
      <div class="fold v" style="left:33.3%"></div>
      <div class="fold v" style="left:66.6%"></div>
      <div class="fold h" style="top:50%"></div>

      <svg id="map-svg" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 860 600" preserveAspectRatio="xMidYMid meet">
        <defs>
          <filter id="rough" x="-4%" y="-4%" width="108%" height="108%">
            <feTurbulence type="fractalNoise" baseFrequency="0.04" numOctaves="3" seed="12" result="n"/>
            <feDisplacementMap in="SourceGraphic" in2="n" scale="1.5" xChannelSelector="R" yChannelSelector="G"/>
          </filter>
          <linearGradient id="goldLine" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stop-color="transparent"/>
            <stop offset="50%" stop-color="#b8902a" stop-opacity="0.7"/>
            <stop offset="100%" stop-color="transparent"/>
          </linearGradient>
        </defs>
        <rect x="12" y="12" width="836" height="576" rx="4" fill="none" stroke="#1a3a2e" stroke-width="1.2" opacity="0.3"/>
        <rect x="18" y="18" width="824" height="564" rx="3" fill="none" stroke="#b8902a" stroke-width="0.6" opacity="0.4" stroke-dasharray="5 4"/>
        <g opacity="0.5" stroke="#b8902a" stroke-width="0.8" fill="none">
          <path d="M22 22 L50 22 M22 22 L22 50 M22 22 L34 34"/>
          <path d="M838 22 L810 22 M838 22 L838 50 M838 22 L826 34"/>
          <path d="M22 578 L50 578 M22 578 L22 550 M22 578 L34 566"/>
          <path d="M838 578 L810 578 M838 578 L838 550 M838 578 L826 566"/>
        </g>
        <g filter="url(#rough)" opacity="0.12" fill="#1a3a2e">
          <ellipse cx="430" cy="130" rx="38" ry="44"/>
          <rect x="398" y="172" width="64" height="110" rx="12"/>
          <rect x="404" y="280" width="24" height="90" rx="10"/>
          <rect x="432" y="280" width="24" height="90" rx="10"/>
        </g>
        <g filter="url(#rough)" stroke="#1a3a2e" stroke-width="0.9" fill="none" opacity="0.72">
          <rect x="52" y="55" width="155" height="100" rx="3"/>
          <rect x="650" y="55" width="158" height="100" rx="3"/>
          <rect x="40" y="230" width="160" height="110" rx="3"/>
          <rect x="660" y="230" width="158" height="110" rx="3"/>
          <rect x="52" y="420" width="155" height="100" rx="3"/>
          <rect x="650" y="420" width="158" height="100" rx="3"/>
          <rect x="310" y="430" width="240" height="110" rx="3"/>
          <rect x="318" y="60" width="224" height="100" rx="3"/>
          <rect x="310" y="230" width="240" height="140" rx="5"/>
          <path d="M207 105 L318 105" stroke-width="0.8"/>
          <path d="M542 105 L650 105" stroke-width="0.8"/>
          <path d="M430 160 L430 230" stroke-width="0.7" stroke-dasharray="4 3" opacity="0.6"/>
          <path d="M207 470 L310 470" stroke-width="0.8"/>
          <path d="M550 470 L650 470" stroke-width="0.8"/>
        </g>
        <g font-family="'Cormorant Garamond', serif" font-style="italic" fill="#1a3a2e" opacity="0.82">
          <text x="130" y="74" font-size="10" text-anchor="middle" font-style="normal" font-weight="400" opacity="0.9" letter-spacing="1">MIND &amp; WELLNESS</text>
          <text x="729" y="74" font-size="10" text-anchor="middle" font-style="normal" opacity="0.9" letter-spacing="1">NUTRITION</text>
          <text x="120" y="247" font-size="10" text-anchor="middle" font-style="normal" opacity="0.9" letter-spacing="0.8">AYURVEDA</text>
          <text x="739" y="247" font-size="10" text-anchor="middle" font-style="normal" opacity="0.9" letter-spacing="0.8">FITNESS</text>
          <text x="130" y="436" font-size="10" text-anchor="middle" font-style="normal" opacity="0.9" letter-spacing="0.8">DIAGNOSTICS</text>
          <text x="729" y="436" font-size="10" text-anchor="middle" font-style="normal" opacity="0.9" letter-spacing="0.8">REHABILITATION</text>
          <text x="430" y="77" font-size="10" text-anchor="middle" font-style="normal" opacity="0.9" letter-spacing="1">CONSULTATION</text>
          <text x="430" y="447" font-size="10" text-anchor="middle" font-style="normal" opacity="0.9" letter-spacing="0.8">HOLISTIC CENTRE</text>
          <text x="430" y="278" font-size="13" text-anchor="middle" font-style="italic" opacity="0.65">IndoGulf</text>
          <text x="430" y="296" font-size="10" text-anchor="middle" font-style="normal" opacity="0.55" letter-spacing="2">WELLNESS CORE</text>
          <text x="430" y="316" font-size="8.5" text-anchor="middle" opacity="0.45">Where all paths converge</text>
        </g>
        <g fill="#2d5c46">
          <circle class="pulse-dot" cx="130" cy="155" r="4" opacity="0.8" style="animation-delay:0s"/>
          <circle class="pulse-dot" cx="729" cy="155" r="4" opacity="0.8" style="animation-delay:0.4s"/>
          <circle class="pulse-dot" cx="120" cy="340" r="4" opacity="0.8" style="animation-delay:0.8s"/>
          <circle class="pulse-dot" cx="739" cy="340" r="4" opacity="0.8" style="animation-delay:1.2s"/>
          <circle class="pulse-dot" cx="130" cy="420" r="4" opacity="0.8" style="animation-delay:1.6s"/>
          <circle class="pulse-dot" cx="729" cy="420" r="4" opacity="0.8" style="animation-delay:2s"/>
          <circle class="pulse-dot" cx="430" cy="300" r="6" fill="#1a3a2e" opacity="0.7" style="animation-delay:0.2s"/>
        </g>
        <g id="steps-layer" opacity="0.65"/>
        <g transform="translate(796,550)">
          <circle cx="0" cy="0" r="28" fill="#b8902a" opacity="0.85" stroke="#7a6020" stroke-width="1.2"/>
          <text x="0" y="-6" font-size="8" text-anchor="middle" font-family="'Cinzel',serif" fill="#f0ebe0" letter-spacing="1">IGW</text>
          <text x="0" y="8" font-size="6" text-anchor="middle" font-family="'Cormorant Garamond',serif" fill="#f0ebe0" font-style="italic">wellness</text>
        </g>
      </svg>

      <div id="ftr"><span>~ touch anywhere to begin your journey ~</span></div>
    </div>
  </div>
</div>

<!-- ════ MAIN SITE ════ -->
<div id="main-site">
  <div class="cursor" id="cursor"></div>
  <div class="cursor-ring" id="cursorRing"></div>

  <nav id="navbar">
    <a href="<?php echo home_url('/'); ?>" class="nav-logo">Indogulf<span>Wellness</span></a>
    <ul class="nav-links">
      <li><a href="#services">Programs</a></li>
      <li><a href="#ayurveda">Ayurveda</a></li>
      <li><a href="#mindfulness">Mindfulness</a></li>
      <li><a href="#programs">Retreats</a></li>
    </ul>
    <a href="#cta" class="nav-cta">Begin Journey</a>
  </nav>

  <section id="hero">
    <canvas id="three-canvas"></canvas>
    <div class="hero-content">
      <p class="hero-eyebrow">Establishing Peace &amp; Harmony</p>
      <h1 class="hero-title">Awaken the<br><em>sacred stillness</em><br>within</h1>
      <p class="hero-sub">Immerse in transformative yoga, Ayurvedic nutrition, mindfulness counselling and stress restoration — a complete path to wholeness.</p>
      <div class="hero-btns">
        <a href="#services" class="btn-primary">Explore Programs</a>
        <a href="#cta" class="btn-outline">Free Consultation</a>
      </div>
    </div>
    <div class="scroll-indicator">
      <div class="scroll-line"></div>
      <span>Scroll</span>
    </div>
  </section>

  <div class="marquee-section">
    <div class="marquee-track">
      <div class="marquee-item">Hatha Yoga</div>
      <div class="marquee-item">Ayurvedic Nutrition</div>
      <div class="marquee-item">Aqua Therapy</div>
      <div class="marquee-item">Mindfulness Counselling</div>
      <div class="marquee-item">Stress Management</div>
      <div class="marquee-item">Pranayama</div>
      <div class="marquee-item">Dosha Balancing</div>
      <div class="marquee-item">Swimming Therapy</div>
      <div class="marquee-item">Hatha Yoga</div>
      <div class="marquee-item">Ayurvedic Nutrition</div>
      <div class="marquee-item">Aqua Therapy</div>
      <div class="marquee-item">Mindfulness Counselling</div>
      <div class="marquee-item">Stress Management</div>
      <div class="marquee-item">Pranayama</div>
      <div class="marquee-item">Dosha Balancing</div>
      <div class="marquee-item">Swimming Therapy</div>
    </div>
  </div>

  <section id="services">
    <div class="reveal">
      <p class="section-label">What we offer</p>
      <h2 class="section-title" style="color:var(--deep)">Six pillars of<br><em style="font-family:'Cormorant Garamond',serif;font-style:italic">holistic healing</em></h2>
    </div>
    <div class="services-grid">
      <div class="service-card s1"><div class="service-bg"></div><div class="service-icon">🧘</div><div class="service-num">01</div><div class="service-content"><div class="service-name">Yoga Therapy</div><div class="service-desc">Personalised asana sequences aligned with your constitution — Hatha, Yin, Restorative, and therapeutic practices.</div></div></div>
      <div class="service-card s2"><div class="service-bg"></div><div class="service-icon">🌊</div><div class="service-num">02</div><div class="service-content"><div class="service-name">Swimming &amp; Aqua Healing</div><div class="service-desc">Hydrotherapy and guided swimming programs to improve circulation, reduce inflammation, and calm the nervous system.</div></div></div>
      <div class="service-card s3"><div class="service-bg"></div><div class="service-icon">🌿</div><div class="service-num">03</div><div class="service-content"><div class="service-name">Ayurvedic Diet Plans</div><div class="service-desc">Dosha-specific meal programs crafted by Ayurvedic physicians — seasonal, sattvic, and deeply nourishing.</div></div></div>
      <div class="service-card s4"><div class="service-bg"></div><div class="service-icon">🧠</div><div class="service-num">04</div><div class="service-content"><div class="service-name">Mindfulness Counselling</div><div class="service-desc">One-on-one and group sessions integrating mindfulness-based cognitive therapy, breathwork, and somatic awareness.</div></div></div>
      <div class="service-card s5"><div class="service-bg"></div><div class="service-icon">💆</div><div class="service-num">05</div><div class="service-content"><div class="service-name">Stress Management</div><div class="service-desc">Evidence-based protocols combining pranayama, NSDR techniques, Yoga Nidra, and nervous system regulation.</div></div></div>
      <div class="service-card s6"><div class="service-bg"></div><div class="service-icon">☀️</div><div class="service-num">06</div><div class="service-content"><div class="service-name">Panchakarma Detox</div><div class="service-desc">Traditional five-fold purification therapies — Abhyanga, Shirodhara, and deep Ayurvedic cleansing rituals.</div></div></div>
    </div>
  </section>

  <section id="ayurveda">
    <div class="reveal-left">
      <p class="section-label">Ancient Science of Life</p>
      <h2 class="section-title">Discover your<br><em style="font-family:'Cormorant Garamond',serif;font-style:italic;color:var(--gold-main)">Ayurvedic self</em></h2>
      <p style="margin:1.5rem 0 2.5rem;font-size:0.9rem;color:rgba(245,240,232,0.6);line-height:1.8;max-width:440px;">Every diet plan is woven around your unique Prakriti — the ancient Ayurvedic blueprint of your physical and mental nature.</p>
      <a href="#cta" class="btn-primary" style="font-size:0.78rem">Take Dosha Quiz</a>
    </div>
    <div class="reveal">
      <div class="dosha-grid">
        <div class="dosha-card"><div class="dosha-icon">🔥</div><div class="dosha-name">Vata</div><div class="dosha-elem">Air · Space</div><div class="dosha-text">Warming, grounding foods. Favour ghee, sesame, root vegetables, and warming spices to pacify Vata imbalance.</div></div>
        <div class="dosha-card"><div class="dosha-icon">☀️</div><div class="dosha-name">Pitta</div><div class="dosha-elem">Fire · Water</div><div class="dosha-text">Cooling, sweet foods. Coconut, leafy greens, mint, and bitter herbs balance Pitta's fiery intensity.</div></div>
        <div class="dosha-card" style="grid-column:1/-1"><div class="dosha-icon">🌍</div><div class="dosha-name">Kapha</div><div class="dosha-elem">Earth · Water</div><div class="dosha-text">Light, pungent, and dry foods. Ginger, turmeric, legumes, and bitter greens energise and uplift Kapha constitution.</div></div>
        <div class="dosha-card" style="grid-column:1/-1;background:rgba(212,168,67,0.08);border-color:rgba(212,168,67,0.3)"><div style="font-family:'Cormorant Garamond',serif;font-size:1.1rem;font-style:italic;color:var(--gold-main);margin-bottom:0.5rem">"Let food be thy medicine"</div><div style="font-size:0.78rem;color:rgba(245,240,232,0.5)">Seasonal meal plans · Weekly consultations · Herb &amp; supplement guidance</div></div>
      </div>
    </div>
  </section>

  <div class="stats-bar">
    <div><div class="stat-num" data-target="2400">0</div><div class="stat-label">Lives transformed</div></div>
    <div><div class="stat-num" data-target="18">0</div><div class="stat-label">Expert practitioners</div></div>
    <div><div class="stat-num" data-target="94">0</div><div class="stat-label">% stress reduction rate</div></div>
    <div><div class="stat-num" data-target="12">0</div><div class="stat-label">Years of excellence</div></div>
  </div>

  <section id="programs">
    <div class="reveal">
      <p class="section-label" style="color:var(--earth)">Our Retreats</p>
      <h2 class="section-title">Immersive healing<br>journeys</h2>
    </div>
    <div class="programs-list">
      <div class="program-item"><span class="prog-num">01</span><div><div class="prog-name">Morning Yoga &amp; Swim Immersion</div><div class="prog-tag">7-day · Beginner friendly</div></div><div class="prog-arrow">→</div></div>
      <div class="program-item"><span class="prog-num">02</span><div><div class="prog-name">Ayurvedic Detox &amp; Reset</div><div class="prog-tag">14-day · All doshas</div></div><div class="prog-arrow">→</div></div>
      <div class="program-item"><span class="prog-num">03</span><div><div class="prog-name">Stress Dissolution Retreat</div><div class="prog-tag">5-day · Intensive · Executive wellness</div></div><div class="prog-arrow">→</div></div>
      <div class="program-item"><span class="prog-num">04</span><div><div class="prog-name">Mindfulness &amp; MBCT Program</div><div class="prog-tag">8-week · Online &amp; In-person</div></div><div class="prog-arrow">→</div></div>
      <div class="program-item"><span class="prog-num">05</span><div><div class="prog-name">Aqua Therapy &amp; Recovery</div><div class="prog-tag">3-month · Therapeutic · Chronic conditions</div></div><div class="prog-arrow">→</div></div>
    </div>
  </section>

  <section id="mindfulness">
    <canvas id="mind-canvas"></canvas>
    <div>
      <div class="reveal-left">
        <p class="section-label">Inner Work</p>
        <h2 class="section-title">The art of<br><em style="font-family:'Cormorant Garamond',serif;font-style:italic;color:var(--gold-main)">mindful living</em></h2>
        <p style="margin:1.5rem 0 2.5rem;font-size:0.88rem;color:rgba(245,240,232,0.6);line-height:1.8">Our counselling integrates Buddhist mindfulness, somatic therapy, and modern neuroscience.</p>
      </div>
      <div class="mind-features">
        <div class="mind-feat reveal"><div class="mind-feat-icon">🌬️</div><div><div class="mind-feat-title">Breathwork &amp; Pranayama</div><div class="mind-feat-text">Nadi Shodhana, Kapalabhati, and Box Breathing sessions that recalibrate the autonomic nervous system.</div></div></div>
        <div class="mind-feat reveal"><div class="mind-feat-icon">🌙</div><div><div class="mind-feat-title">Yoga Nidra &amp; NSDR</div><div class="mind-feat-text">40-minute guided sessions equivalent to 4 hours of deep sleep — scientifically documented neural restoration.</div></div></div>
        <div class="mind-feat reveal"><div class="mind-feat-icon">💬</div><div><div class="mind-feat-title">1-on-1 Counselling</div><div class="mind-feat-text">Private sessions with certified mindfulness therapists trained in MBCT, ACT, and trauma-informed care.</div></div></div>
      </div>
    </div>
  </section>

  <section id="testimonials">
    <div class="reveal">
      <p class="section-label" style="color:rgba(250,247,240,0.6)">Voices of healing</p>
      <h2 class="section-title">What our community<br>shares</h2>
    </div>
    <div class="testi-slider" id="testiSlider">
      <div class="testi-card"><div class="testi-stars">★★★★★</div><div class="testi-text">"The Ayurvedic diet plan completely changed my relationship with food. Three months in, my digestion, energy, and sleep are transformed."</div><div class="testi-author">— Priya M., Mumbai · Pitta Programme</div></div>
      <div class="testi-card"><div class="testi-stars">★★★★★</div><div class="testi-text">"The stress management retreat was life-altering. I came in running on empty and left with tools I use every single morning."</div><div class="testi-author">— Rahul K., Delhi · Executive Wellness</div></div>
      <div class="testi-card"><div class="testi-stars">★★★★★</div><div class="testi-text">"Aqua therapy alongside yoga — I never imagined swimming could be this meditative. My chronic back pain has reduced by 80%."</div><div class="testi-author">— Ananya S., Bangalore · Aqua Recovery</div></div>
      <div class="testi-card"><div class="testi-stars">★★★★★</div><div class="testi-text">"The mindfulness counsellor helped me see the patterns driving my anxiety. Profound, life-changing work."</div><div class="testi-author">— Kabir R., Pune · MBCT Programme</div></div>
      <div class="testi-card"><div class="testi-stars">★★★★★</div><div class="testi-text">"Seven days of morning yoga and swimming left me more rested than any holiday I've ever taken. I'll be back every year."</div><div class="testi-author">— Meera T., Chennai · Morning Immersion</div></div>
    </div>
  </section>

  <section id="cta">
    <p class="section-label reveal" style="text-align:center">Begin today</p>
    <h2 class="section-title reveal">Your journey to<br><em style="font-family:'Cormorant Garamond',serif;font-style:italic;color:var(--gold-main)">wholeness</em> starts<br>with one breath</h2>
    <p class="cta-sub reveal">Free 30-minute discovery consultation with a wellness advisor. No commitment — just a conversation about your path.</p>
    <a href="mailto:hello@indogulfwellness.com" class="btn-primary reveal" style="font-size:0.85rem;letter-spacing:0.15em">Book Free Consultation</a>
  </section>

  <footer>
    <div>
      <div class="footer-logo">Indogulf<span>Wellness</span></div>
      <div class="footer-desc">Blending the timeless wisdom of Ayurveda with modern therapeutic science. Gurugram · Delhi NCR · Online worldwide.</div>
    </div>
    <div>
      <div class="footer-col-title">Programs</div>
      <ul class="footer-links">
        <li><a href="#">Yoga Therapy</a></li>
        <li><a href="#">Swimming &amp; Aqua</a></li>
        <li><a href="#">Ayurvedic Diet</a></li>
        <li><a href="#">Stress Retreats</a></li>
      </ul>
    </div>
    <div>
      <div class="footer-col-title">Resources</div>
      <ul class="footer-links">
        <li><a href="#">Dosha Quiz</a></li>
        <li><a href="#">Blog &amp; Recipes</a></li>
        <li><a href="#">Guided Meditations</a></li>
        <li><a href="#">Research Library</a></li>
      </ul>
    </div>
    <div>
      <div class="footer-col-title">Connect</div>
      <ul class="footer-links">
        <li><a href="#">Instagram</a></li>
        <li><a href="#">YouTube</a></li>
        <li><a href="#">WhatsApp</a></li>
        <li><a href="mailto:hello@indogulfwellness.com">hello@indogulfwellness.com</a></li>
      </ul>
    </div>
    <div class="footer-bottom">© <?php echo date('Y'); ?> IndoGulf Wellness. All rights reserved.</div>
  </footer>
</div>

<?php get_footer(); ?>
