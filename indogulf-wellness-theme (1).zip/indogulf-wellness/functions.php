<?php
/**
 * IndoGulf Wellness — functions.php
 * Enqueues all theme styles and scripts.
 */

function indogulf_enqueue_assets() {

    // Google Fonts
    wp_enqueue_style(
        'indogulf-fonts',
        'https://fonts.googleapis.com/css2?family=Cinzel:wght@400;600&family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;1,300;1,400&family=DM+Sans:wght@300;400;500&display=swap',
        array(),
        null
    );

    // Main stylesheet
    wp_enqueue_style(
        'indogulf-style',
        get_stylesheet_uri(),
        array('indogulf-fonts'),
        '1.0.0'
    );

    // GSAP
    wp_enqueue_script(
        'gsap',
        'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js',
        array(),
        '3.12.5',
        true
    );

    // GSAP ScrollTrigger
    wp_enqueue_script(
        'gsap-scrolltrigger',
        'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/ScrollTrigger.min.js',
        array('gsap'),
        '3.12.5',
        true
    );

    // Three.js
    wp_enqueue_script(
        'threejs',
        'https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js',
        array(),
        'r128',
        true
    );

    // Theme script
    wp_enqueue_script(
        'indogulf-script',
        get_template_directory_uri() . '/script.js',
        array('gsap', 'gsap-scrolltrigger', 'threejs'),
        '1.0.0',
        true
    );
}
add_action('wp_enqueue_scripts', 'indogulf_enqueue_assets');


/**
 * Theme setup
 */
function indogulf_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', array('search-form', 'comment-form', 'gallery', 'caption'));
}
add_action('after_setup_theme', 'indogulf_setup');
